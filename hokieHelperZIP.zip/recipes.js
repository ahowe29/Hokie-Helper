/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

module.exports = {
    "make friends": "Leave your dorm room door open, find clubs to join on gobbler connect dot v t dot e d you, join intramural sports, rush greek life, or find a study buddy.",
    "get food": "Walk down main street to find great restaurant like the cellar or Chipotle or stay on campus and go to Turners at Lavery Place on the academic side, or go to West End near West AJ, or go to Owens near the cadets housing. ",
    "find food": "Walk down main street to find great restaurant like the cellar or Chipotle or stay on campus and go to Turners at Lavery Place on the academic side, or go to West End near West AJ, or go to Owens near the cadets housing. ",
    "eat dinner": "Walk down main street to find great restaurant like the cellar or Chipotle or stay on campus and go to Turners at Lavery Place on the academic side, or go to West End near West AJ, or go to Owens near the cadets housing. ",
    "hiking": "Dragons Tooth, McAfees Knob, or the Cascades are all great hikes. Or go check out Virginia Tech's Venture Out in Squires. To learn more about venture out ask what is Venture Out.",
    "venture out": "Venture Out is a Virginia Tech resource that takes groups of hokies hiking, rock climbing, white water rafting, horse back riding, and more for a small price.",
    "get technology support": "Contact Virginia Tech four help at 540-231-4357.",
    "for computer help": "Contact Virginia Tech four help at 540-231-4357.",
    "get computer help": "Contact Virginia Tech four help at 540-231-4357.",
    "get tech support": "Contact Virginia Tech four help at 540-231-4357.",
    "get help studying": "Check out the Student Success Center in 110 Femoyer Hall for free individual or group tutoring.",
    "get help with my class schedule": "See your academic advisor. Hokie spa can tell you who your advisor is.",
    "get a copy of my transcript": "You can get an unoffical transcript off of Hokie spa or see the University Registrar for an offical transcript.",
    "play sports": "Join an intramural sports team or club team. Visit the Virginia Tech rec sports website for more information.",
    "workout": "Go to war memorial or to McComas Rec Center.",
    "a hokie": "You are.",
    "study": "Go to Newman Library, torgeson bridge, or empty class rooms.",
    "find parties": "Oak lane or pheasant run are usual party spots on weekends.",
    "get football tickets": "Enter the student lottery online at hokie tickets dot com for a chance to get free student tickets.",
    "get tickets": "Enter the student lottery online at hokie tickets dot com for a chance to get free student tickets.",
    "study abroad": "Virginia Tech offers short two week faculty led programs, semester exchange programs, or year long programs. If you're a first semester general engineering freshman definitely apply to the Rising Sophomore Abraod Program, it's a great experience. Visit the Global Education office at 526 Prices Fork Road, Room 131, or call 540-231-5888 to learn more.",
    "free stuff at Virgina Tech": "Through the library you can get free Rosetta Stone, you can use your hokie passport to get student discounts at stores such as jay crew, and you can get free massages during exam week.",
    "take workout classes": "Classes take place in war memorial or in the McComas Rec Center seven days a week. Free classes are offered during exam weeks.",
    "to learn about my tuition or fees": "Call the University Bursar at 540-231-6277, or visit them in person at 800 Washington Street Suite 150.",
    "anxious": "Check out Cooks Counseling Center across from McComas Rec Center open Monday through Friday 8am to 5pm. Call at 540-231-6557 during regular hours, 540-231-6444 for after hours or weekends.",
    "depressed": "Check out Cooks Counseling Center across from McComas Rec Center open Monday through Friday 8am to 5pm. Call at 540-231-6557 during regular hours, 540-231-6444 for after hours or weekends.",
    "worried": "Check out Cooks Counseling Center across from McComas Rec Center open Monday through Friday 8am to 5pm. Call at 540-231-6557 during regular hours, 540-231-6444 for after hours or weekends.",
    "suicidal": "Please call the National Suicide Prevention Hotline at 1-800-273-8255. For resources at Virginia Tech please call 540-231-6557 for help at Virginia Tech. Also check out Cooks Counseling Center across from McComas Rec Center open Monday through Friday 8am to 5pm. Call at 540-231-6557 during regular hours, 540-231-6444 for after hours or weekends.",
    "scared": " Call the Virginia Tech Police at 911 for emergencies or 540-231-6411 for non-emergencies. Also check out Cooks Counseling Center across from McComas Rec Center open Monday through Friday 8am to 5pm. Call at 540-231-6557 during regular hours, 540-231-6444 for after hours or weekends.",
    "if my friend has been sexually assualted": "Please call the National Sexual Assault Hotline at 1-800-656-4673. Also please call and make an appointment at the womens center at 540-231-6444. The womens center can refer you to many additional resources at Virginia Tech.",
    "if I have been sexually assualted": "Please call the National Sexual Assault Hotline at 1-800-656-4673. Also please call and make an appointment at the womens center at 540-231-6444. The womens center can refer you to many additional resources at Virginia Tech.",
    "don't feel well": "If you don't feel well go to Shiffert Health Center located across from McComas Rec Center. Either walk in or call 540-231-6444 to make an appointment at either the health center or womens clinic.",
    "sick": "If you don't feel well go to Shiffert Health Center located across from McComas Rec Center. Either walk in or call 540-231-6444 to make an appointment at either the health center or womens clinic."
};



